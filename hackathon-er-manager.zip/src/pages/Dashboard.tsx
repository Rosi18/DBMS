import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogOut, Trophy, Users, FileCode2, Star } from 'lucide-react';

export function Dashboard({ user, setUser }: { user: any, setUser: (user: any) => void }) {
  const navigate = useNavigate();
  const [hackathons, setHackathons] = useState([]);
  const [teams, setTeams] = useState([]);
  const [submissions, setSubmissions] = useState([]);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    fetchData();
  }, [user, navigate]);

  const fetchData = async () => {
    const [hackRes, teamRes, subRes] = await Promise.all([
      fetch('/api/hackathons'),
      fetch('/api/teams'),
      fetch('/api/submissions')
    ]);
    setHackathons(await hackRes.json());
    setTeams(await teamRes.json());
    setSubmissions(await subRes.json());
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('user');
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Trophy className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">HackManage</span>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm text-gray-500">Welcome, {user?.name} ({user?.role})</span>
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 text-gray-500 hover:text-gray-700"
              >
                <LogOut className="h-5 w-5" />
                Logout
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        {user?.role === 'admin' && <AdminDashboard hackathons={hackathons} teams={teams} fetchData={fetchData} />}
        {user?.role === 'participant' && <ParticipantDashboard hackathons={hackathons} user={user} teams={teams} fetchData={fetchData} />}
        {user?.role === 'judge' && <JudgeDashboard submissions={submissions} hackathons={hackathons} teams={teams} user={user} fetchData={fetchData} />}
      </main>
    </div>
  );
}

function AdminDashboard({ hackathons, teams, fetchData }: { hackathons: any[], teams: any[], fetchData: () => void }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const handleCreateHackathon = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetch('/api/hackathons', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, description, start_date: startDate, end_date: endDate, status: 'active' }),
    });
    fetchData();
    setTitle('');
    setDescription('');
    setStartDate('');
    setEndDate('');
  };

  return (
    <div className="space-y-6">
      <div className="bg-white shadow rounded-lg p-6">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Create New Hackathon</h2>
        <form onSubmit={handleCreateHackathon} className="space-y-4">
          <input
            type="text"
            placeholder="Hackathon Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          />
          <textarea
            placeholder="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            rows={3}
            required
          />
          <div className="grid grid-cols-2 gap-4">
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
              required
            />
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
              required
            />
          </div>
          <button type="submit" className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">
            Create Hackathon
          </button>
        </form>
      </div>

      <div className="bg-white shadow rounded-lg p-6">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Manage Hackathons</h2>
        <div className="space-y-4">
          {hackathons.map((h) => (
            <div key={h.id} className="border border-gray-200 rounded-md p-4 flex justify-between items-center">
              <div>
                <h3 className="font-medium text-gray-900">{h.title}</h3>
                <p className="text-sm text-gray-500">{h.start_date} to {h.end_date}</p>
              </div>
              <span className={`px-2 py-1 text-xs rounded-full ${h.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                {h.status}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white shadow rounded-lg p-6">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Registered Teams & Participants</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Team Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Domain</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Lead Details</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Members</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {teams.map((t) => (
                <tr key={t.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{t.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{t.domain || 'N/A'}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    <div><strong>{t.lead_name || 'N/A'}</strong></div>
                    <div>{t.lead_email}</div>
                    <div>{t.lead_contact}</div>
                    <div>{t.lead_college}</div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    <ul className="list-disc pl-4">
                      {t.member1_name && <li>{t.member1_name} ({t.member1_contact})</li>}
                      {t.member2_name && <li>{t.member2_name} ({t.member2_contact})</li>}
                      {t.member3_name && <li>{t.member3_name} ({t.member3_contact})</li>}
                      {t.member4_name && <li>{t.member4_name} ({t.member4_contact})</li>}
                      {!t.member1_name && !t.member2_name && !t.member3_name && !t.member4_name && <li>No additional members</li>}
                    </ul>
                  </td>
                </tr>
              ))}
              {teams.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-6 py-4 text-center text-sm text-gray-500">No teams registered yet.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function ParticipantDashboard({ hackathons, user, teams, fetchData }: { hackathons: any[], user: any, teams: any[], fetchData: () => void }) {
  const DOMAINS = ['AI', 'Cloud Computing', 'Cyber Security', 'ML', 'Finance and Banking'];
  const [teamName, setTeamName] = useState('');
  const [selectedDomain, setSelectedDomain] = useState('');
  
  const [leadName, setLeadName] = useState(user?.name || '');
  const [leadEmail, setLeadEmail] = useState(user?.email || '');
  const [leadContact, setLeadContact] = useState('');
  const [leadCollege, setLeadCollege] = useState('');
  
  const [member1Name, setMember1Name] = useState('');
  const [member1Contact, setMember1Contact] = useState('');
  const [member2Name, setMember2Name] = useState('');
  const [member2Contact, setMember2Contact] = useState('');
  const [member3Name, setMember3Name] = useState('');
  const [member3Contact, setMember3Contact] = useState('');
  const [member4Name, setMember4Name] = useState('');
  const [member4Contact, setMember4Contact] = useState('');
  
  const [submissionTitle, setSubmissionTitle] = useState('');
  const [submissionDesc, setSubmissionDesc] = useState('');
  const [githubLink, setGithubLink] = useState('');
  const [videoLink, setVideoLink] = useState('');

  const handleCreateTeam = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetch('/api/teams', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        name: teamName, 
        domain: selectedDomain, 
        leader_id: user.id,
        lead_name: leadName,
        lead_email: leadEmail,
        lead_contact: leadContact,
        lead_college: leadCollege,
        member1_name: member1Name,
        member1_contact: member1Contact,
        member2_name: member2Name,
        member2_contact: member2Contact,
        member3_name: member3Name,
        member3_contact: member3Contact,
        member4_name: member4Name,
        member4_contact: member4Contact
      }),
    });
    fetchData();
    setTeamName('');
    setSelectedDomain('');
    setLeadContact('');
    setLeadCollege('');
    setMember1Name(''); setMember1Contact('');
    setMember2Name(''); setMember2Contact('');
    setMember3Name(''); setMember3Contact('');
    setMember4Name(''); setMember4Contact('');
  };

  const handleSubmitProject = async (e: React.FormEvent) => {
    e.preventDefault();
    const team = teams.find(t => t.leader_id === user.id);
    if (!team) {
      alert('You must create a team first!');
      return;
    }

    await fetch('/api/submissions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        team_id: team.id,
        hackathon_id: null,
        title: submissionTitle,
        description: submissionDesc,
        github_link: githubLink,
        video_link: videoLink
      }),
    });
    fetchData();
    setSubmissionTitle('');
    setSubmissionDesc('');
    setGithubLink('');
    setVideoLink('');
  };

  return (
    <div className="space-y-6">
      <div className="bg-white shadow rounded-lg p-6">
        <h2 className="text-lg font-medium text-gray-900 mb-4 flex items-center gap-2">
          <Users className="h-5 w-5 text-indigo-500" />
          Create a Team (Max 5 Participants)
        </h2>
        <form onSubmit={handleCreateTeam} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <select
              value={selectedDomain}
              onChange={(e) => setSelectedDomain(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
              required
            >
              <option value="">Select Domain</option>
              {DOMAINS.map(d => <option key={d} value={d}>{d}</option>)}
            </select>
            <input
              type="text"
              placeholder="Team Name"
              value={teamName}
              onChange={(e) => setTeamName(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
              required
            />
          </div>

          <div className="border-t border-gray-200 pt-4">
            <h3 className="text-md font-medium text-gray-800 mb-3">Team Lead Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input type="text" placeholder="Lead Name" value={leadName} onChange={(e) => setLeadName(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md" required />
              <input type="email" placeholder="Lead Email" value={leadEmail} onChange={(e) => setLeadEmail(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md" required />
              <input type="text" placeholder="Lead Contact" value={leadContact} onChange={(e) => setLeadContact(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md" required />
              <input type="text" placeholder="Lead College" value={leadCollege} onChange={(e) => setLeadCollege(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md" required />
            </div>
          </div>

          <div className="border-t border-gray-200 pt-4">
            <h3 className="text-md font-medium text-gray-800 mb-3">Member 1 Details (Optional)</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input type="text" placeholder="Member 1 Name" value={member1Name} onChange={(e) => setMember1Name(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md" />
              <input type="text" placeholder="Member 1 Contact" value={member1Contact} onChange={(e) => setMember1Contact(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md" />
            </div>
          </div>

          <div className="border-t border-gray-200 pt-4">
            <h3 className="text-md font-medium text-gray-800 mb-3">Member 2 Details (Optional)</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input type="text" placeholder="Member 2 Name" value={member2Name} onChange={(e) => setMember2Name(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md" />
              <input type="text" placeholder="Member 2 Contact" value={member2Contact} onChange={(e) => setMember2Contact(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md" />
            </div>
          </div>

          <div className="border-t border-gray-200 pt-4">
            <h3 className="text-md font-medium text-gray-800 mb-3">Member 3 Details (Optional)</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input type="text" placeholder="Member 3 Name" value={member3Name} onChange={(e) => setMember3Name(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md" />
              <input type="text" placeholder="Member 3 Contact" value={member3Contact} onChange={(e) => setMember3Contact(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md" />
            </div>
          </div>

          <div className="border-t border-gray-200 pt-4">
            <h3 className="text-md font-medium text-gray-800 mb-3">Member 4 Details (Optional)</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input type="text" placeholder="Member 4 Name" value={member4Name} onChange={(e) => setMember4Name(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md" />
              <input type="text" placeholder="Member 4 Contact" value={member4Contact} onChange={(e) => setMember4Contact(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md" />
            </div>
          </div>

          <button type="submit" className="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">
            Create Team
          </button>
        </form>
      </div>

      <div className="bg-white shadow rounded-lg p-6">
        <h2 className="text-lg font-medium text-gray-900 mb-4 flex items-center gap-2">
          <FileCode2 className="h-5 w-5 text-indigo-500" />
          Submit Project
        </h2>
        <form onSubmit={handleSubmitProject} className="space-y-4 max-w-2xl">
          {teams.find(t => t.leader_id === user.id) ? (
            <div className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-md text-gray-700">
              Submitting for team: <strong>{teams.find(t => t.leader_id === user.id)?.name}</strong>
            </div>
          ) : (
            <div className="px-3 py-2 bg-red-50 border border-red-200 rounded-md text-red-600">
              Please create a team before submitting a project.
            </div>
          )}
          <input
            type="text"
            placeholder="Project Title"
            value={submissionTitle}
            onChange={(e) => setSubmissionTitle(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          />
          <textarea
            placeholder="Project Description"
            value={submissionDesc}
            onChange={(e) => setSubmissionDesc(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            rows={3}
            required
          />
          <input
            type="url"
            placeholder="GitHub Repository URL"
            value={githubLink}
            onChange={(e) => setGithubLink(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          />
          <input
            type="url"
            placeholder="Demo Video URL"
            value={videoLink}
            onChange={(e) => setVideoLink(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          />
          <button type="submit" className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700">
            Submit Project
          </button>
        </form>
      </div>
    </div>
  );
}

function JudgeDashboard({ submissions, hackathons, teams, user, fetchData }: { submissions: any[], hackathons: any[], teams: any[], user: any, fetchData: () => void }) {
  const [score, setScore] = useState('');
  const [feedback, setFeedback] = useState('');
  const [selectedSubmission, setSelectedSubmission] = useState<any>(null);

  const handleScoreSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSubmission) return;

    await fetch('/api/scores', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        submission_id: selectedSubmission.id,
        judge_id: user.id,
        score: parseInt(score),
        feedback
      }),
    });
    fetchData();
    setSelectedSubmission(null);
    setScore('');
    setFeedback('');
  };

  return (
    <div className="space-y-6">
      <div className="bg-white shadow rounded-lg p-6">
        <h2 className="text-lg font-medium text-gray-900 mb-4 flex items-center gap-2">
          <Star className="h-5 w-5 text-amber-500" />
          Evaluate Submissions
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="col-span-1 border-r border-gray-200 pr-4">
            <h3 className="font-medium text-gray-700 mb-3">Pending Reviews</h3>
            <div className="space-y-2">
              {submissions.map(sub => (
                <button
                  key={sub.id}
                  onClick={() => setSelectedSubmission(sub)}
                  className={`w-full text-left p-3 rounded-md border ${selectedSubmission?.id === sub.id ? 'border-indigo-500 bg-indigo-50' : 'border-gray-200 hover:bg-gray-50'}`}
                >
                  <p className="font-medium text-gray-900 truncate">{sub.title}</p>
                  <p className="text-xs text-gray-500 truncate">Domain: {teams.find(t => t.id === sub.team_id)?.domain || 'N/A'}</p>
                </button>
              ))}
            </div>
          </div>
          
          <div className="col-span-2">
            {selectedSubmission ? (
              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-bold text-gray-900">{selectedSubmission.title}</h3>
                  <p className="text-gray-600 mt-2">{selectedSubmission.description}</p>
                  <div className="mt-4 flex gap-4">
                    <a href={selectedSubmission.github_link} target="_blank" rel="noreferrer" className="text-indigo-600 hover:underline text-sm">GitHub Repo</a>
                    <a href={selectedSubmission.video_link} target="_blank" rel="noreferrer" className="text-indigo-600 hover:underline text-sm">Demo Video</a>
                  </div>
                </div>
                
                <form onSubmit={handleScoreSubmit} className="space-y-4 border-t border-gray-200 pt-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Score (1-100)</label>
                    <input
                      type="number"
                      min="1"
                      max="100"
                      value={score}
                      onChange={(e) => setScore(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Feedback</label>
                    <textarea
                      value={feedback}
                      onChange={(e) => setFeedback(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                      rows={4}
                      required
                    />
                  </div>
                  <button type="submit" className="bg-amber-500 text-white px-4 py-2 rounded-md hover:bg-amber-600">
                    Submit Evaluation
                  </button>
                </form>
              </div>
            ) : (
              <div className="h-full flex items-center justify-center text-gray-500">
                Select a submission to evaluate
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
