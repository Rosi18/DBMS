import { 
  Trophy, User, Building, Users, UserCheck, 
  FileText, UploadCloud, Gavel, Gift 
} from 'lucide-react';

export const entities = {
  Hackathon: {
    name: 'Hackathon',
    icon: Trophy,
    color: 'bg-purple-500',
    lightColor: 'bg-purple-50',
    textColor: 'text-purple-600',
    attributes: [
      { name: 'Hackathon_ID', type: 'text' },
      { name: 'Title', type: 'text' },
      { name: 'Theme', type: 'text' },
      { name: 'Mode', type: 'select', options: ['Online', 'Offline', 'Hybrid'] },
      { name: 'Date', type: 'date' }
    ]
  },
  User: {
    name: 'User',
    icon: User,
    color: 'bg-blue-500',
    lightColor: 'bg-blue-50',
    textColor: 'text-blue-600',
    attributes: [
      { name: 'User_ID', type: 'text' },
      { name: 'Name', type: 'text' },
      { name: 'Email', type: 'email' },
      { name: 'Role', type: 'select', options: ['Admin', 'Organizer', 'Participant', 'Judge'] }
    ]
  },
  Organization: {
    name: 'Organization',
    icon: Building,
    color: 'bg-indigo-500',
    lightColor: 'bg-indigo-50',
    textColor: 'text-indigo-600',
    attributes: [
      { name: 'Organization_ID', type: 'text' },
      { name: 'Name', type: 'text' },
      { name: 'Location', type: 'text' },
      { name: 'Type', type: 'select', options: ['College', 'Company', 'NGO', 'Other'] }
    ]
  },
  Team: {
    name: 'Team',
    icon: Users,
    color: 'bg-emerald-500',
    lightColor: 'bg-emerald-50',
    textColor: 'text-emerald-600',
    attributes: [
      { name: 'Team_ID', type: 'text' },
      { name: 'Team_Name', type: 'text' },
      { name: 'Team_Leader_Name', type: 'text' }
    ]
  },
  Participant: {
    name: 'Participant',
    icon: UserCheck,
    color: 'bg-teal-500',
    lightColor: 'bg-teal-50',
    textColor: 'text-teal-600',
    attributes: [
      { name: 'Participant_ID', type: 'text' },
      { name: 'Name', type: 'text' }
    ]
  },
  ProblemStatement: {
    name: 'Problem Statement',
    icon: FileText,
    color: 'bg-orange-500',
    lightColor: 'bg-orange-50',
    textColor: 'text-orange-600',
    attributes: [
      { name: 'Problem_ID', type: 'text' },
      { name: 'Domain', type: 'text' },
      { name: 'Description', type: 'textarea' }
    ]
  },
  Submission: {
    name: 'Submission',
    icon: UploadCloud,
    color: 'bg-red-500',
    lightColor: 'bg-red-50',
    textColor: 'text-red-600',
    attributes: [
      { name: 'Submission_ID', type: 'text' },
      { name: 'GitHub_Link', type: 'url' },
      { name: 'Prototype', type: 'text' },
      { name: 'Result', type: 'text' },
      { name: 'Testing_Analysis', type: 'textarea' }
    ]
  },
  Judges: {
    name: 'Judges',
    icon: Gavel,
    color: 'bg-amber-500',
    lightColor: 'bg-amber-50',
    textColor: 'text-amber-600',
    attributes: [
      { name: 'Judge_ID', type: 'text' },
      { name: 'Name', type: 'text' },
      { name: 'Slot', type: 'text' },
      { name: 'Remarks', type: 'textarea' }
    ]
  },
  Prizes: {
    name: 'Prizes',
    icon: Gift,
    color: 'bg-pink-500',
    lightColor: 'bg-pink-50',
    textColor: 'text-pink-600',
    attributes: [
      { name: 'Prize_ID', type: 'text' },
      { name: 'Winner', type: 'text' },
      { name: 'Runner', type: 'text' },
      { name: 'Participant_Certificates', type: 'select', options: ['Yes', 'No'] }
    ]
  }
};
