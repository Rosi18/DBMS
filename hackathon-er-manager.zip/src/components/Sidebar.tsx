import React from 'react';
import { entities } from '../config/entities';
import { motion } from 'motion/react';
import { Database } from 'lucide-react';

interface SidebarProps {
  activeEntity: string;
  setActiveEntity: (entity: string) => void;
}

export function Sidebar({ activeEntity, setActiveEntity }: SidebarProps) {
  return (
    <div className="w-64 bg-gray-900 text-white flex flex-col h-full shadow-xl z-10 flex-shrink-0">
      <div className="p-6 flex items-center gap-3 border-b border-gray-800">
        <div className="p-2 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg shadow-lg">
          <Database size={24} className="text-white" />
        </div>
        <h1 className="text-xl font-bold tracking-tight">Hackathon Manager</h1>
      </div>
      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1 custom-scrollbar">
        {Object.entries(entities).map(([key, config]) => {
          const Icon = config.icon;
          const isActive = activeEntity === key;
          
          // Extract the color name (e.g., 'purple' from 'bg-purple-500')
          const colorName = config.color.split('-')[1];
          const activeTextColor = `text-${colorName}-400`;

          return (
            <button
              key={key}
              onClick={() => setActiveEntity(key)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 relative overflow-hidden group ${
                isActive ? 'text-white' : 'text-gray-400 hover:text-white hover:bg-gray-800'
              }`}
            >
              {isActive && (
                <motion.div
                  layoutId="activeTab"
                  className={`absolute inset-0 ${config.color} opacity-20`}
                  initial={false}
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                />
              )}
              {isActive && (
                <motion.div
                  layoutId="activeIndicator"
                  className={`absolute left-0 top-0 bottom-0 w-1 ${config.color}`}
                  initial={false}
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                />
              )}
              <Icon 
                size={20} 
                className={`relative z-10 transition-colors ${isActive ? activeTextColor : 'group-hover:text-gray-200'}`} 
              />
              <span className="font-medium relative z-10">{config.name}</span>
            </button>
          );
        })}
      </nav>
      <div className="p-4 border-t border-gray-800 text-xs text-gray-500 text-center">
        Management System
      </div>
    </div>
  );
}
