import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Trash2, Search, Database } from 'lucide-react';

interface EntityViewProps {
  entityKey: string;
  entityConfig: any;
  data: any[];
  onAdd: (record: any) => void;
  onDelete: (id: string) => void;
}

export function EntityView({ entityKey, entityConfig, data, onAdd, onDelete }: EntityViewProps) {
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [isAdding, setIsAdding] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const Icon = entityConfig.icon;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdd(formData);
    setFormData({});
    setIsAdding(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>, attrName: string) => {
    setFormData(prev => ({ ...prev, [attrName]: e.target.value }));
  };

  const filteredData = data.filter(item => 
    Object.values(item).some(val => 
      String(val).toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  return (
    <div className="h-full flex flex-col bg-gray-50/50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-8 py-6 flex items-center justify-between sticky top-0 z-10 shadow-sm">
        <div className="flex items-center gap-4">
          <div className={`p-3 rounded-2xl ${entityConfig.lightColor}`}>
            <Icon size={32} className={entityConfig.textColor} />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">{entityConfig.name}s</h2>
            <p className="text-sm text-gray-500">Manage your {entityConfig.name.toLowerCase()} records and details</p>
          </div>
        </div>
        <button
          onClick={() => setIsAdding(!isAdding)}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-white font-medium transition-all active:scale-95 ${entityConfig.color} hover:opacity-90 shadow-md`}
        >
          <Plus size={20} className={`transition-transform duration-300 ${isAdding ? 'rotate-45' : ''}`} />
          {isAdding ? 'Cancel' : `Add ${entityConfig.name}`}
        </button>
      </header>

      <div className="flex-1 overflow-y-auto p-8">
        <AnimatePresence>
          {isAdding && (
            <motion.div
              initial={{ opacity: 0, height: 0, marginBottom: 0 }}
              animate={{ opacity: 1, height: 'auto', marginBottom: 32 }}
              exit={{ opacity: 0, height: 0, marginBottom: 0 }}
              className="overflow-hidden"
            >
              <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2">
                  <Plus size={20} className={entityConfig.textColor} />
                  New {entityConfig.name} Record
                </h3>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {entityConfig.attributes.map((attr: any) => (
                      <div key={attr.name}>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">
                          {attr.name.replace(/_/g, ' ')}
                        </label>
                        {attr.type === 'select' ? (
                          <select
                            value={formData[attr.name] || ''}
                            onChange={(e) => handleChange(e, attr.name)}
                            className="w-full px-4 py-2.5 rounded-xl border border-gray-300 focus:ring-2 focus:ring-opacity-20 focus:border-transparent outline-none transition-all bg-white"
                            style={{ '--tw-ring-color': 'currentColor' } as any}
                          >
                            <option value="">Select...</option>
                            {attr.options.map((opt: string) => (
                              <option key={opt} value={opt}>{opt}</option>
                            ))}
                          </select>
                        ) : attr.type === 'textarea' ? (
                          <textarea
                            value={formData[attr.name] || ''}
                            onChange={(e) => handleChange(e, attr.name)}
                            className="w-full px-4 py-2.5 rounded-xl border border-gray-300 focus:ring-2 focus:ring-opacity-20 focus:border-transparent outline-none transition-all"
                            rows={3}
                            placeholder={`Enter ${attr.name.replace(/_/g, ' ').toLowerCase()}...`}
                          />
                        ) : (
                          <input
                            type={attr.type}
                            value={formData[attr.name] || ''}
                            onChange={(e) => handleChange(e, attr.name)}
                            className="w-full px-4 py-2.5 rounded-xl border border-gray-300 focus:ring-2 focus:ring-opacity-20 focus:border-transparent outline-none transition-all"
                            placeholder={`Enter ${attr.name.replace(/_/g, ' ').toLowerCase()}...`}
                          />
                        )}
                      </div>
                    ))}
                  </div>
                  <div className="flex justify-end pt-4 border-t border-gray-100">
                    <button
                      type="submit"
                      className={`px-6 py-2.5 rounded-xl text-white font-medium transition-all hover:opacity-90 active:scale-95 ${entityConfig.color}`}
                    >
                      Save Record
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Data Table */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden flex flex-col">
          <div className="p-5 border-b border-gray-200 bg-gray-50/80 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
              <Database size={20} className="text-gray-400" />
              Saved Records
            </h3>
            <div className="relative w-full sm:w-auto">
              <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search records..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full sm:w-72 rounded-xl border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-gray-200 transition-all"
              />
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-white border-b border-gray-200">
                  {entityConfig.attributes.map((attr: any) => (
                    <th key={attr.name} className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider whitespace-nowrap bg-gray-50/50">
                      {attr.name.replace(/_/g, ' ')}
                    </th>
                  ))}
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider text-right bg-gray-50/50">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredData.length === 0 ? (
                  <tr>
                    <td colSpan={entityConfig.attributes.length + 1} className="px-6 py-16 text-center text-gray-500 bg-white">
                      <div className="flex flex-col items-center justify-center">
                        <div className={`p-4 rounded-full ${entityConfig.lightColor} mb-4`}>
                          <Database size={32} className={entityConfig.textColor} />
                        </div>
                        <p className="text-lg font-medium text-gray-900 mb-1">No records found</p>
                        <p className="text-sm text-gray-500">
                          {searchTerm ? 'Try adjusting your search query.' : `Add a new ${entityConfig.name.toLowerCase()} to populate this table.`}
                        </p>
                      </div>
                    </td>
                  </tr>
                ) : (
                  filteredData.map((item, idx) => (
                    <motion.tr 
                      key={item._id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: Math.min(idx * 0.05, 0.5) }}
                      className="hover:bg-gray-50/80 transition-colors group bg-white"
                    >
                      {entityConfig.attributes.map((attr: any) => (
                        <td key={attr.name} className="px-6 py-4 text-sm text-gray-700 whitespace-nowrap">
                          {attr.type === 'url' && item[attr.name] ? (
                            <a href={item[attr.name]} target="_blank" rel="noopener noreferrer" className={`${entityConfig.textColor} hover:underline`}>
                              {item[attr.name]}
                            </a>
                          ) : (
                            item[attr.name]
                          )}
                        </td>
                      ))}
                      <td className="px-6 py-4 text-right">
                        <button
                          onClick={() => onDelete(item._id)}
                          className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100"
                          title="Delete Record"
                        >
                          <Trash2 size={18} />
                        </button>
                      </td>
                    </motion.tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
