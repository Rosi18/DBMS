import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import Database from 'better-sqlite3';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const db = new Database('hackathon.db');

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS Users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS Hackathons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    start_date TEXT,
    end_date TEXT,
    status TEXT DEFAULT 'upcoming'
  );

  CREATE TABLE IF NOT EXISTS Teams (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    hackathon_id INTEGER,
    leader_id INTEGER,
    FOREIGN KEY(hackathon_id) REFERENCES Hackathons(id),
    FOREIGN KEY(leader_id) REFERENCES Users(id)
  );

  CREATE TABLE IF NOT EXISTS TeamMembers (
    team_id INTEGER,
    user_id INTEGER,
    PRIMARY KEY(team_id, user_id),
    FOREIGN KEY(team_id) REFERENCES Teams(id),
    FOREIGN KEY(user_id) REFERENCES Users(id)
  );

  CREATE TABLE IF NOT EXISTS Submissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    team_id INTEGER,
    hackathon_id INTEGER,
    title TEXT NOT NULL,
    description TEXT,
    github_link TEXT,
    video_link TEXT,
    FOREIGN KEY(team_id) REFERENCES Teams(id),
    FOREIGN KEY(hackathon_id) REFERENCES Hackathons(id)
  );

  CREATE TABLE IF NOT EXISTS Scores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    submission_id INTEGER,
    judge_id INTEGER,
    score INTEGER,
    feedback TEXT,
    FOREIGN KEY(submission_id) REFERENCES Submissions(id),
    FOREIGN KEY(judge_id) REFERENCES Users(id)
  );
`);

// Add new columns safely if they don't exist
try { db.exec('ALTER TABLE Teams ADD COLUMN domain TEXT'); } catch (e) {}
try { db.exec('ALTER TABLE Teams ADD COLUMN join_code TEXT'); } catch (e) {}
try { db.exec('ALTER TABLE Teams ADD COLUMN lead_name TEXT'); } catch (e) {}
try { db.exec('ALTER TABLE Teams ADD COLUMN lead_email TEXT'); } catch (e) {}
try { db.exec('ALTER TABLE Teams ADD COLUMN lead_contact TEXT'); } catch (e) {}
try { db.exec('ALTER TABLE Teams ADD COLUMN lead_college TEXT'); } catch (e) {}
try { db.exec('ALTER TABLE Teams ADD COLUMN member1_name TEXT'); } catch (e) {}
try { db.exec('ALTER TABLE Teams ADD COLUMN member1_contact TEXT'); } catch (e) {}
try { db.exec('ALTER TABLE Teams ADD COLUMN member2_name TEXT'); } catch (e) {}
try { db.exec('ALTER TABLE Teams ADD COLUMN member2_contact TEXT'); } catch (e) {}
try { db.exec('ALTER TABLE Teams ADD COLUMN member3_name TEXT'); } catch (e) {}
try { db.exec('ALTER TABLE Teams ADD COLUMN member3_contact TEXT'); } catch (e) {}
try { db.exec('ALTER TABLE Teams ADD COLUMN member4_name TEXT'); } catch (e) {}
try { db.exec('ALTER TABLE Teams ADD COLUMN member4_contact TEXT'); } catch (e) {}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  
  // Auth
  app.post('/api/auth/register', (req, res) => {
    const { name, email, password, role } = req.body;
    try {
      const stmt = db.prepare('INSERT INTO Users (name, email, password, role) VALUES (?, ?, ?, ?)');
      const info = stmt.run(name, email, password, role);
      res.json({ id: info.lastInsertRowid, name, email, role });
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body;
    const user = db.prepare('SELECT * FROM Users WHERE email = ? AND password = ?').get(email, password) as any;
    if (user) {
      res.json({ id: user.id, name: user.name, email: user.email, role: user.role });
    } else {
      res.status(401).json({ error: 'Invalid credentials' });
    }
  });

  // Hackathons
  app.get('/api/hackathons', (req, res) => {
    const hackathons = db.prepare('SELECT * FROM Hackathons').all();
    res.json(hackathons);
  });

  app.post('/api/hackathons', (req, res) => {
    const { title, description, start_date, end_date, status } = req.body;
    try {
      const stmt = db.prepare('INSERT INTO Hackathons (title, description, start_date, end_date, status) VALUES (?, ?, ?, ?, ?)');
      const info = stmt.run(title, description, start_date, end_date, status || 'upcoming');
      res.json({ id: info.lastInsertRowid });
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  // Teams
  app.get('/api/teams', (req, res) => {
    const teams = db.prepare('SELECT * FROM Teams').all();
    res.json(teams);
  });

  app.post('/api/teams', (req, res) => {
    const { 
      name, domain, leader_id,
      lead_name, lead_email, lead_contact, lead_college,
      member1_name, member1_contact,
      member2_name, member2_contact,
      member3_name, member3_contact,
      member4_name, member4_contact
    } = req.body;
    try {
      const stmt = db.prepare(`
        INSERT INTO Teams (
          name, domain, leader_id,
          lead_name, lead_email, lead_contact, lead_college,
          member1_name, member1_contact,
          member2_name, member2_contact,
          member3_name, member3_contact,
          member4_name, member4_contact
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      const info = stmt.run(
        name, domain, leader_id,
        lead_name, lead_email, lead_contact, lead_college,
        member1_name, member1_contact,
        member2_name, member2_contact,
        member3_name, member3_contact,
        member4_name, member4_contact
      );
      
      // Add leader to TeamMembers
      db.prepare('INSERT INTO TeamMembers (team_id, user_id) VALUES (?, ?)').run(info.lastInsertRowid, leader_id);
      
      res.json({ id: info.lastInsertRowid });
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  app.post('/api/teams/:id/join', (req, res) => {
    const { user_id, join_code } = req.body;
    const team_id = req.params.id;
    try {
      const team = db.prepare('SELECT * FROM Teams WHERE id = ?').get(team_id) as any;
      if (!team) return res.status(404).json({ error: 'Team not found' });
      
      if (team.join_code && team.join_code !== join_code) {
        return res.status(401).json({ error: 'Invalid join credentials' });
      }

      db.prepare('INSERT INTO TeamMembers (team_id, user_id) VALUES (?, ?)').run(team_id, user_id);
      res.json({ success: true });
    } catch (err: any) {
      if (err.message.includes('UNIQUE constraint failed')) {
        return res.status(400).json({ error: 'Already a member of this team' });
      }
      res.status(400).json({ error: err.message });
    }
  });

  app.get('/api/teams/:id/members', (req, res) => {
    const team_id = req.params.id;
    const members = db.prepare(`
      SELECT Users.id, Users.name, Users.email 
      FROM TeamMembers 
      JOIN Users ON TeamMembers.user_id = Users.id 
      WHERE TeamMembers.team_id = ?
    `).all(team_id);
    res.json(members);
  });

  // Submissions
  app.get('/api/submissions', (req, res) => {
    const submissions = db.prepare('SELECT * FROM Submissions').all();
    res.json(submissions);
  });

  app.post('/api/submissions', (req, res) => {
    const { team_id, hackathon_id, title, description, github_link, video_link } = req.body;
    try {
      const stmt = db.prepare('INSERT INTO Submissions (team_id, hackathon_id, title, description, github_link, video_link) VALUES (?, ?, ?, ?, ?, ?)');
      const info = stmt.run(team_id, hackathon_id, title, description, github_link, video_link);
      res.json({ id: info.lastInsertRowid });
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  // Scores
  app.get('/api/scores', (req, res) => {
    const scores = db.prepare('SELECT * FROM Scores').all();
    res.json(scores);
  });

  app.post('/api/scores', (req, res) => {
    const { submission_id, judge_id, score, feedback } = req.body;
    try {
      const stmt = db.prepare('INSERT INTO Scores (submission_id, judge_id, score, feedback) VALUES (?, ?, ?, ?)');
      const info = stmt.run(submission_id, judge_id, score, feedback);
      res.json({ id: info.lastInsertRowid });
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
